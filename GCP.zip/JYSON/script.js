<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excel Data Display</title>
</head>
<body>
    <h1>Data from Excel</h1>
    <table id="excelDataTable">
        <!-- Data will be inserted here -->
    </table>
    <script src="script.js"></script>
</body>
</html>
